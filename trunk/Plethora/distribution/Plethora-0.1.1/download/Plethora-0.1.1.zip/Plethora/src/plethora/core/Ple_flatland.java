package plethora.core;

import processing.core.*;
import toxi.geom.*;
import peasy.*;

public class Ple_flatland {

	Vec3D loc;
	float w;
	float h;
	PApplet p5;
	PeasyCam cam;
	Vec3D dragNode;

	Ple_flatland(PApplet _p5, PeasyCam _cam, Vec3D _loc, float _w, float _h){
		p5 = _p5;
		cam = _cam;
		loc = _loc;
		w = _w;
		h = _h;
		dragNode = new Vec3D(loc.x,loc.y+h,0);
	}

	/**
	 * 
	 */
	public void run(){
		lockCamera();
		display();		
		resize();
	}
	
	/**
	 * 
	 */
	void lockCamera(){
		if(p5.mouseX > loc.x && p5.mouseX < (loc.x+w)){
			if(p5.mouseY > loc.y && p5.mouseY < (loc.y+h)){
				cam.setActive(false);
			}
		}
	}

	void vLine(Vec3D v1, Vec3D v2){
		p5.line(v1.x,v1.y,v1.z,v2.x,v2.y,v2.z);
	}
	void vLine2d(Vec3D v1, Vec3D v2){
		p5.line(v1.x,v1.y,v2.x,v2.y);
	}

	void vPoint(Vec3D v){
		p5.point(v.x,v.y,v.z);
	}

	/**
	 * 
	 */
	void resize(){

		float difW = 0;
		float difH = 0;

		float d = dragNode.distanceTo(new Vec3D(p5.mouseX, p5.mouseY,0));
		if(d < 30 && p5.mousePressed){
			cam.setActive(false);

			dragNode.x = p5.mouseX;
			dragNode.y = p5.mouseY;

			//newW = (loc.x + w)- dragNode.x;
			//newH = (loc.y) - dragNode.y; ////----------

			difW = loc.x - dragNode.x;
			difH = (loc.y + h) - dragNode.y;

			loc.x -= difW;
			//loc.y -= difH;

			w += difW;
			h -= difH;
		}
	}

	
	/**
	 * 
	 */
	void display(){
		p5.stroke(255,80);
		p5.fill(0,50);
		p5.strokeWeight(1);
		p5.rect(loc.x,loc.y,w,h);

		p5.stroke(255,80);
		p5.ellipse(dragNode.x,dragNode.y,7,7);
	}
}

