package plethora.core;

import peasy.PeasyCam;
import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PImage;
import toxi.geom.Vec3D;

public class Ple_Particle {

	PApplet p5;
	Vec3D loc;
	Vec3D vel;
	Vec3D acc = new Vec3D();
	Vec3D dir;

	int life = 0;
	//float pSize = 20;
	float var = 0.2f;

	int myG = 255;
	int myB = 255;
	
	float size;
	float alpha;

	Ple_Emmiter parent;

	PImage image;


	/**
	 * 
	 * @param _p5
	 * @param _loc
	 * @param _vel
	 * @param _myG
	 * @param _myB
	 */
	public Ple_Particle(PApplet _p5, Ple_Emmiter _parent, PImage _image, Vec3D _loc, Vec3D _vel, int _myG, int _myB){
		p5 = _p5;
		parent = _parent;
		image = _image;

		loc = _loc;
		vel = _vel;
		myG = _myG;
		myB = _myB;

		//vel.normalize();
		//vel.scaleSelf(1.4f);

		dir = new Vec3D (p5.random(-var, var), p5.random(-var, var), 0);

		size = parent.size;
		alpha = parent.alpha;
	}

	/**
	 * 
	 * @param img
	 * @param cam
	 */
	public void run(PeasyCam cam) {	    
		//loc.z = 20;   
		display(image, cam); 
		calcMov();
		update();
		//borders();
		life++;
	}

	/**
	 * 
	 */
	public void update() {
		//acc.addSelf(dir);
		acc.addSelf(parent.grav);

		vel.addSelf(acc);

		loc.addSelf(vel); 
		acc = new Vec3D();
	}


	/**
	 * 
	 * @param z
	 * @param drag
	 */
	public void bounce(float z, float drag){	
		if(loc.z < z){
			vel.z *= -1;
			vel.scaleSelf(drag);
		}

	}


	/**
	 * 
	 * @param img
	 * @param cam
	 */
	void display(PImage img, PeasyCam cam) {
		if(life > 50){
		renderImage(img, cam, loc, size, size, 0, myG, myB, alpha);
		}else{
		renderImage(img, cam, loc, size, size, 0, myG, myB, life/5);
		}
	}

	/**
	 * 
	 * @param rate
	 * @param min
	 * @param max
	 */
	public void changeSize(float rate, float min, float max){
		size += rate;

		if(size < min)size = min;
		if(size > max)size = max;
	}

	/**
	 * 
	 * @param rate
	 * @param min
	 * @param max
	 */
	public void changeAlpha(float rate, float min, float max){
		alpha += rate;

		if(size < min)size = min;
		if(size > max)size = max;
	}

	/**
	 * 
	 */
	public void borders(){	    
		if(loc.x < 0){
			// life = 0; 
		}
		if(loc.y < 0){
			life = 0; 
		}

	}

	/**
	 * 
	 * @param img
	 * @param cam
	 * @param _loc
	 * @param _diamX
	 * @param _diamY
	 * @param _colR
	 * @param _colG
	 * @param _colB
	 * @param _alpha
	 */
	public void renderImage(PImage img, PeasyCam cam, Vec3D _loc, float _diamX, float _diamY, int _colR, int _colG, int _colB, float _alpha ) {
		float rots[] = cam.getRotations();
		p5.noFill();
		p5.noStroke();
		//float camPos[] = cam.getPosition();

		//Vec3D cP = new Vec3D(camPos[0], camPos[1], camPos[2]);

		//float dist = cP.distanceTo(_loc);
		//float coef = map(dist, 700, 0, 0.2f, 1);
		//if(coef < 0.7f) coef = 0.7f;
		//if (coef > 1.0f) coef = 1.0f;
		//if(dist < 300.0f) coef = 1.0f;

		//_diam *= coef;
		//noStroke();

		p5.pushStyle();
		p5.pushMatrix();
		p5.translate( _loc.x, _loc.y, _loc.z );

		p5.rotateX((float) (rots[0]));
		p5.rotateY((float) (rots[1]));
		p5.rotateZ((float) (rots[2]));

		// tint(red(_colR), green(_colG), blue(_colB), _alpha);
		//tint(0,0,255,10);

		//tint(coef, _alpha);
		p5.tint(255, _alpha);
		p5.imageMode(PConstants.CENTER);
		p5.image(img, 0, 0, _diamX, _diamY);
		p5.popMatrix();
		p5.popStyle();
	}

	/**
	 * 
	 */
	public void calcMov() {

		//float stre = PApplet.map(life, 0, 300, 0.0001f, 0.01f);  
		//float stre2 = PApplet.map(life, 0, 300, 0.0001f, 0.014f);

		//dir.normalize();
		//dir.scaleSelf(stre);

		//grav.normalize();
		//grav.scaleSelf(stre2);
	}


}
