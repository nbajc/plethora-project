package plethora.core;

import processing.core.PApplet;
import processing.core.PConstants;
import toxi.geom.Spline3D;
import toxi.geom.Vec3D;
import toxi.geom.mesh.TriangleMesh;
import toxi.processing.ToxiclibsSupport;

public class Ple_Bodies {

	PApplet p5;

	Spline3D sp;

	float randomShift1;
	float randomShift2;
	float randomShift3;
	float randomShift4;
	float randomShift5;

	float randomRoof;

	ToxiclibsSupport gfx;

	TriangleMesh mesh = new TriangleMesh("meshy");

	public Ple_Bodies(PApplet _p5){
		p5 = _p5;
		gfx = new ToxiclibsSupport(p5);

		randomShift1 = p5.random(-1,1);
		randomShift2 = p5.random(-1,1);
		randomShift3 = p5.random(-1,1);	
		randomShift4 = p5.random(-1,0);
		randomShift5 = p5.random(-1,0);
		randomRoof = p5.random(0,0.6f);

	}

	/**
	 * 
	 * @param loc
	 * @param anchor
	 * @param MULT01
	 * @param MULT02
	 * @param MULT03
	 * @param MULT04
	 * @param MULT05
	 * @param MULT06
	 * @param W01
	 * @param W02
	 * @param Height
	 */
	public void createGeometry(Vec3D loc, Vec3D anchor,   float MULT01, float MULT02,  float MULT03,  float MULT04,  float MULT05,
			float MULT06, float W01, float W02, float Height, float direction){

		Spline3D s = buildSplineForm(loc, anchor, MULT01, MULT02, MULT03, MULT04, MULT05, MULT06, W01, W02, direction);

		Spline3D t = extrudeSp(s, Height);

		capSpline(s,0);
		capSpline(t,1);

		p5.beginShape(p5.TRIANGLES);
		gfx.mesh(mesh, true, 0);  
		p5.endShape();

		mesh.clear();

	}

	/**
	 * 
	 * @param sp
	 * @param side
	 */
	public void capSpline(Spline3D sp, int side){

		Vec3D v1 = (Vec3D) sp.pointList.get(0);
		Vec3D v2 = (Vec3D) sp.pointList.get(1);
		Vec3D v3 = (Vec3D) sp.pointList.get(2);
		Vec3D v4 = (Vec3D) sp.pointList.get(3);
		Vec3D v5= (Vec3D) sp.pointList.get(4);
		Vec3D v6 = (Vec3D) sp.pointList.get(5);	
		Vec3D v7= (Vec3D) sp.pointList.get(6);
		Vec3D v8 = (Vec3D) sp.pointList.get(7);

		if(side == 0){
			mesh.addFace(v1, v2, v7);
			mesh.addFace(v7, v8, v1);

			mesh.addFace(v2, v3, v6);
			mesh.addFace(v6, v7, v2);

			mesh.addFace(v3, v4, v5);
			mesh.addFace(v5, v6, v3);
		}else{
			mesh.addFace(v1, v7, v2);
			mesh.addFace(v7, v1, v8);

			mesh.addFace(v2, v6, v3);
			mesh.addFace(v6, v2, v7);

			mesh.addFace(v3, v5, v4);
			mesh.addFace(v5, v3, v6);	
		}
	}

	/**
	 * 
	 * @param loc
	 * @param anchor
	 * @param MULT01
	 * @param MULT02
	 * @param MULT03
	 * @param MULT04
	 * @param MULT05
	 * @param MULT06
	 * @param W01
	 * @param W02
	 * @param direction
	 * @return
	 */
	public Spline3D buildSplineForm (Vec3D loc, Vec3D anchor,   float MULT01, float MULT02,  float MULT03,  float MULT04,  float MULT05,
			float MULT06, float W01, float W02,    float direction){

		Spline3D sp = new Spline3D();

		Vec3D p2 = loc.copy();
		Vec3D p1 = anchor.copy();

		float sc1 = randomShift1 * MULT01;
		float sc2 = randomShift2 * MULT02;
		float sc3 = direction * MULT03;

		float sc4 = MULT04;
		float sc5 = MULT05;

		float rlenback = randomShift4 * MULT06;

		Vec3D pt1 = anyPoint(p1,p2,1.0f,W01+sc1,0);
		sp.add(pt1);

		Vec3D pt2 = anyPoint(p1,p2,sc4,W02+sc3,0);
		sp.add(pt2);

		Vec3D pt3 = anyPoint(p1,p2,sc5,W02+sc3,0);
		sp.add(pt3);

		Vec3D pt4 = anyPoint(p1,p2,0 + rlenback,W01+sc2,0);
		sp.add(pt4);

		Vec3D pt5 = anyPoint(p1,p2,0 + rlenback,-W01+sc2,0);
		sp.add(pt5);

		Vec3D pt6 = anyPoint(p1,p2,sc5,-W02+sc3,0);
		sp.add(pt6);

		Vec3D pt7 = anyPoint(p1,p2,sc4,-W02+sc3,0);
		sp.add(pt7);

		Vec3D pt8 = anyPoint(p1,p2,1.0f,-W01+sc1,0);
		sp.add(pt8);

		sp.add(pt1);

		return sp;
	}

	/**
	 * 
	 * @param v
	 */
	public void vex(Vec3D v){
		p5.vertex(v.x,v.y,v.z);
	}

	Spline3D extrudeSp(Spline3D sp, float z){

		//if(mj == 0)z*=0.8;
		float rZ = z + (z*randomRoof);
		Vec3D up = new Vec3D (0,0,z);
		Vec3D up2 = new Vec3D (0,0,rZ);

		Spline3D top = new Spline3D();

		Vec3D v0 = (Vec3D) sp.pointList.get(0);
		Vec3D v0z = v0.copy();

		//if(mj != 0){
		v0z.addSelf(up);
		//}else{
		//v0z.addSelf(up2);
		//}
		//top.add(v0z);

		for(int i = 0; i < sp.pointList.size(); i ++){

			Vec3D v1 = (Vec3D) sp.pointList.get(i);
			//Vec3D v2 = (Vec3D) sp.pointList.get(i-1);

			Vec3D v1z = v1.copy();
			//Vec3D v2z = v2.copy();


			//v1z.addSelf(up);
			//v2z.addSelf(up);

			//if(mj != 0){
			v1z.addSelf(up);
			//}else{
			//if(i == 1 || i == 2 || i == 5 || i == 6){
			//v1z.addSelf(up2);
			//}else{
			//v1z.addSelf(up);
			//}
			//}

			top.add(v1z);

			//p5.println("called");
		}

		for(int i = 1; i < sp.pointList.size(); i ++){

			Vec3D v1 = (Vec3D) sp.pointList.get(i);
			Vec3D v2 = (Vec3D) sp.pointList.get(i-1);

			Vec3D v1z = (Vec3D) top.pointList.get(i);
			Vec3D v2z = (Vec3D) top.pointList.get(i-1);

			mesh.addFace(v1, v2, v2z);
			mesh.addFace(v2z, v1z, v1);
		}

		return top;
	}

	/**
	 * 
	 * @param p1
	 * @param p2
	 * @param x
	 * @param y
	 * @param z
	 * @return
	 */
	public Vec3D anyPoint(Vec3D p1, Vec3D p2,float x, float y , float z){
		float distance = p1.distanceTo(p2);

		Vec3D result = new Vec3D(0,0,0);

		//axis = x , rot = y, up = z
		Vec3D axis = p2.sub(p1);
		axis.normalize();
		axis.scaleSelf(distance * x);

		Vec3D rot = p2.sub(p1);
		rot.normalize();
		rot.rotateZ(PApplet.PI/2);
		//rot.scaleSelf(distance * y);
		rot.scaleSelf(y);

		Vec3D up = new Vec3D(0,0,z);

		result.addSelf(axis);
		result.addSelf(rot);
		result.addSelf(up);
		result.addSelf(p1);
		return result;
	}






}
