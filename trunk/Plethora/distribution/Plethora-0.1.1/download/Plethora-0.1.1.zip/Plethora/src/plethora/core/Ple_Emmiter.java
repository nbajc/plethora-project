package plethora.core;

import java.util.ArrayList;

import peasy.PeasyCam;
import processing.core.PApplet;
import processing.core.PImage;
import toxi.geom.Vec3D;

public class Ple_Emmiter {

	PApplet p5;

	Vec3D loc;
	ArrayList <Ple_Particle> parts;
	//int rate = 1;
	int myG = 255;
	int myB = 255;
	float alpha = 255;

	Vec3D grav = new Vec3D();

	ArrayList <PImage> imageBuffer;

	float size;

	Vec3D dir =  new Vec3D(0,0,1);
	float angle = 0;


	/**
	 * 
	 * @param _p5
	 */
	public Ple_Emmiter(PApplet _p5, Vec3D _loc, float _size){
		p5 = _p5;
		loc = _loc;
		size = _size;

		parts = new ArrayList <Ple_Particle> ();

		myG = (int)(p5.random(100,255));
		myB = (int)(p5.random(100,255));

		imageBuffer = new ArrayList <PImage>();
	}

	/**
	 * 
	 */
	public void run() {

		//display();
		//createParticles(0,0,1);
		//createParticles();
		//runParticles();
		linesOnDistance(30,230);
		lineToPreviusParticle(200);
		//killPartciles();
	}

	/**
	 * 
	 * @param rate
	 * @param min
	 * @param max
	 */
	public void changeSize(float rate, float min, float max){
		for (int i = 0; i < parts.size(); i++) {
			Ple_Particle p = (Ple_Particle) parts.get(i);
			p.changeSize(rate, min, max);
		}
	}

	/**
	 * 
	 * @param rate
	 * @param min
	 * @param max
	 */
	public void changeAlpha(float rate, float min, float max){
		for (int i = 0; i < parts.size(); i++) {
			Ple_Particle p = (Ple_Particle) parts.get(i);
			p.changeAlpha(rate, min, max);
		}
	}

	/**
	 * 
	 * @param im
	 */
	public void addImageToBuffer(PImage im){
		imageBuffer.add(im);
	}

	/**
	 * 
	 * @param x
	 * @param y
	 * @param z
	 */
	public void createParticles(PImage img, int rate, float x, float y, float z) {
		if (p5.frameCount % rate ==0) {
			Vec3D l = loc.copy();
			Vec3D v = new Vec3D(x, y, z);
			parts.add(new Ple_Particle(p5, this, img, l, v, myG, myB));
		}
	}

	/**
	 * 
	 * @param x
	 * @param y
	 * @param z
	 */
	public void createParticlesFromBuffer(int rate, float x, float y, float z) {
		if(imageBuffer.size()>0){
			if (p5.frameCount % rate ==0) {
				Vec3D l = loc.copy();
				Vec3D v = new Vec3D(x, y, z);

				int numOfImages = imageBuffer.size();
				int randomImage = (int)p5.random(numOfImages);
				PImage img = (PImage) imageBuffer.get(randomImage);

				parts.add(new Ple_Particle(p5, this, img, l, v, myG, myB));
			}
		}
	}

	/**
	 * 
	 * @param rate
	 * @param strengh
	 * @param random1
	 * @param jitterRate
	 * @param up
	 */
	public void createParticlesFromBufferSpiral(int rate, float strengh, float random1, int jitterRate, float up) {
		if(imageBuffer.size()>0){
			if (p5.frameCount % rate ==0) {
				Vec3D l = loc.copy();
				//Vec3D v = new Vec3D(0, 0, 1);
				angle += p5.random(-random1,random1);

				Vec3D r = new Vec3D(PApplet.cos(angle), PApplet.sin(angle), 0);
				if(p5.frameCount % jitterRate == 0){
					dir.addSelf(r);
					dir.addSelf(0,0,up);
				}

				dir.normalize();
				dir.scaleSelf(strengh);

				Vec3D v = dir.copy();


				int numOfImages = imageBuffer.size();
				int randomImage = (int)p5.random(numOfImages);
				PImage img = (PImage) imageBuffer.get(randomImage);

				parts.add(new Ple_Particle(p5, this, img, l, v, myG, myB));
			}
		}
	}

	/**
	 * 
	 * @param x
	 * @param y
	 * @param z
	 */
	public void setGravity(float x,float y,float z){
		grav = new Vec3D(x,y,z);
	}

	/**
	 * 
	 * @param img
	 * @param cam
	 */
	public void runParticles(PeasyCam cam) {
		for (int i = 0; i < parts.size(); i++) {
			Ple_Particle p = (Ple_Particle) parts.get(i);
			p.run(cam);
		}
	}

	/**
	 * 
	 * @param z
	 * @param drag
	 */
	public void bounce(float z, float drag) {
		for (int i = 0; i < parts.size(); i++) {
			Ple_Particle p = (Ple_Particle) parts.get(i);
			p.bounce(z, drag);
		}
	}

	/**
	 * 
	 * @param life
	 */
	public void lineToPreviusParticle(float life) {
		for (int i = 1; i < parts.size(); i++) {
			Ple_Particle p = (Ple_Particle) parts.get(i);
			Ple_Particle p2 = (Ple_Particle) parts.get(i-1);

			if (p.life < life && p2.life < life) {
				//p5.stroke(0, myG, myB, alph);
				vLine(p.loc, p2.loc);
			}
		}
	}

	/**
	 * 
	 * @param v1
	 * @param v2
	 */
	public void vLine(Vec3D v1, Vec3D v2){
		p5.line(v1.x,v1.y,v1.z, v2.x, v2.y, v2.z);
	}


	/**
	 * 
	 * @param distance
	 * @param life
	 */
	public void linesOnDistance(float distance , float life) {

		for (int i = 0; i < parts.size(); i++) {
			Ple_Particle p = (Ple_Particle) parts.get(i);

			for (int j = 0; j < parts.size(); j++) {
				Ple_Particle p2 = (Ple_Particle) parts.get(j);
				if (i != j) {

					float d = p.loc.distanceTo(p2.loc);

					if (d < distance && p.life < life && p2.life < life) {
						//p5.stroke(0, myG, myB, alph);
						vLine(p.loc, p2.loc);
					}
				}
			}
		}
	}

	/**
	 * 
	 */
	public void killPartciles(int life) {
		for (int i = 0; i < parts.size(); i++) {
			Ple_Particle p = (Ple_Particle) parts.get(i);
			if (p.life > life) {
				parts.remove(p);
			}
		}
	}


	/**
	 * 
	 * @param r
	 * @param g
	 * @param b
	 * @param w
	 */
	public void displayPoint(int r, int g, int b, int w) {	
		p5.strokeWeight(w);
		p5.stroke(r,g,b);
		vPt(loc);
	}

	/**
	 * 
	 * @param v
	 */
	public void vPt(Vec3D v){
		p5.point(v.x,v.y,v.z);
	}





}
