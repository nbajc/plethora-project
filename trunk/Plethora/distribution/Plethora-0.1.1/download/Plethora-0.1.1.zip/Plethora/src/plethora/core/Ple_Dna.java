package plethora.core;

public class Ple_Dna {

	int int1;
	int int2;
	
	Ple_Dna(){
		
	}
	
	
	
	
}
