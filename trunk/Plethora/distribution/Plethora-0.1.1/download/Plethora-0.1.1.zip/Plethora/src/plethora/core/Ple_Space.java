package plethora.core;

import toxi.geom.*;
import processing.core.*;

public class Ple_Space {

	PApplet p5;
	
	public Ple_Space(PApplet _p5){
		p5 = _p5;
	}
	
}
