package plethora.core;

import toxi.geom.Vec3D;

public class Ple_Node {

	public Vec3D loc;
	public int xPos;
	public int yPos;
	
	public float data = 0;
	
	/**
	 * 
	 * @param _loc
	 */
	public Ple_Node(Vec3D _loc){
		
		loc = _loc;
		
	}
	/**
	 * 
	 * @param i
	 * @param j
	 */
	public void setIndex(int i, int j){
		xPos = i;
		yPos = j;
	}
	
	/**
	 * 
	 * @param value
	 */
	public void setData(float value){
		data = value;
	}
	
	
	
	
	
}
